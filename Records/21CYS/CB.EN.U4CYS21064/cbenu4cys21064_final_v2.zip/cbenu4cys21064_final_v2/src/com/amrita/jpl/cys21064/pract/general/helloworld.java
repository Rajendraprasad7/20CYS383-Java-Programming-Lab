package com.amrita.jpl.cys21064.pract.general;

/**
 * @author Rajendraprasad S
 */
public class helloworld {
    /**
     * Prints Hello World!
     */
    public static void main(String args[])
    {
        System.out.println("Hello world!");
    }
}
